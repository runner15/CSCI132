package Linked_List;
import java.io.*;
/**
 * @author Zachariah Fahsi
 */
public class Driver {
    public static void main(String[] args)
    {
        Official official = new Official();
        official.readFile();
        official.setVariables();
        official.createList();
        while(official.checkList())
        {
            official.goAround();
        }
        official.createFile();
    }
}