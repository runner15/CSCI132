package Maze;
/**
 * @author Runner15
 */
public class Driver {
    /*
        Uses file input to get the maze
        This file was submitted with the code 
    */
    public static void main(String[] args) {
        Maze maze = new Maze();
    }
}
